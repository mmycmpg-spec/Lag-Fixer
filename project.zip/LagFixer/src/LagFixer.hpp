#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>

using namespace geode::prelude;

namespace lagfixer {
    // Applies (or undoes) the lag fix using the saved settings
    void apply();
}

class LagFixerPopup : public geode::Popup {
protected:
    CCLabelBMFont* m_fpsLabel = nullptr;
    Slider* m_slider = nullptr;
    CCMenuItemToggler* m_toggle = nullptr;

    bool init();
    void onToggle(CCObject*);
    void onSlider(CCObject*);
    void onPreset(CCObject*);
    void refreshLabel();

public:
    static LagFixerPopup* create();
};
