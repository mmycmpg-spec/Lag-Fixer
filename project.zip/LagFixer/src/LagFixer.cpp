#include "LagFixer.hpp"
#include <algorithm>
#include <cmath>

namespace {
    constexpr int kMinFps = 60;
    constexpr int kMaxFps = 500;

    bool g_savedOriginal = false;
    float g_origFps = 60.f;
    bool g_origPerformance = false;
    bool g_origVsync = false;

    int currentFps() {
        auto v = Mod::get()->getSettingValue<int64_t>("fps");
        return std::clamp<int>(static_cast<int>(v), kMinFps, kMaxFps);
    }

    void setInterval(float fps) {
        if (fps < 1.f) fps = 60.f;
        if (auto* dir = CCDirector::sharedDirector()) {
            dir->setAnimationInterval(1.0 / static_cast<double>(fps));
        }
    }
}

void lagfixer::apply() {
    auto* gm = GameManager::sharedState();
    if (!gm) return;

    // remember how the game was set up before we touched it
    if (!g_savedOriginal) {
        g_savedOriginal = true;
        g_origFps = gm->m_customFPSTarget >= 1.f ? gm->m_customFPSTarget : 60.f;
        g_origPerformance = gm->m_performanceMode;
        g_origVsync = gm->m_vsyncEnabled;
    }

    if (Mod::get()->getSettingValue<bool>("enabled")) {
        float fps = static_cast<float>(currentFps());
        gm->m_customFPSTarget = fps;
        gm->m_performanceMode = true;
        gm->m_vsyncEnabled = false;
        gm->updateCustomFPS();
        setInterval(fps);
    } else {
        gm->m_customFPSTarget = g_origFps;
        gm->m_performanceMode = g_origPerformance;
        gm->m_vsyncEnabled = g_origVsync;
        gm->updateCustomFPS();
        setInterval(g_origFps);
    }
}

// ================================================================
// Popup
// ================================================================

LagFixerPopup* LagFixerPopup::create() {
    auto ret = new LagFixerPopup();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool LagFixerPopup::init() {
    if (!Popup::init(320, 240)) return false;
    setTitle("LAG FIXER");

    float cx = m_size.width / 2;

    auto* menu = CCMenu::create();
    menu->setPosition({0, 0});
    m_mainLayer->addChild(menu);

    // --- Fix Lag check ---
    auto* checkLabel = CCLabelBMFont::create("Fix Lag", "bigFont.fnt");
    checkLabel->setScale(0.6f);
    checkLabel->setPosition({cx - 25, m_size.height - 65});
    m_mainLayer->addChild(checkLabel);

    m_toggle = CCMenuItemToggler::createWithStandardSprites(
        this, menu_selector(LagFixerPopup::onToggle), 0.8f);
    m_toggle->toggle(Mod::get()->getSettingValue<bool>("enabled"));
    m_toggle->setPosition({cx + 65, m_size.height - 65});
    menu->addChild(m_toggle);

    // --- FPS label + slider ---
    m_fpsLabel = CCLabelBMFont::create("FPS: 60", "goldFont.fnt");
    m_fpsLabel->setScale(0.8f);
    m_fpsLabel->setPosition({cx, m_size.height - 110});
    m_mainLayer->addChild(m_fpsLabel);

    m_slider = Slider::create(this, menu_selector(LagFixerPopup::onSlider), 0.8f);
    m_slider->setPosition({cx, m_size.height - 140});
    float v = static_cast<float>(Mod::get()->getSettingValue<int64_t>("fps") - kMinFps) /
              static_cast<float>(kMaxFps - kMinFps);
    m_slider->setValue(std::clamp(v, 0.f, 1.f));
    m_mainLayer->addChild(m_slider);

    auto* minLabel = CCLabelBMFont::create("60", "chatFont.fnt");
    minLabel->setScale(0.6f);
    minLabel->setPosition({cx - 80, m_size.height - 160});
    m_mainLayer->addChild(minLabel);
    auto* maxLabel = CCLabelBMFont::create("500", "chatFont.fnt");
    maxLabel->setScale(0.6f);
    maxLabel->setPosition({cx + 80, m_size.height - 160});
    m_mainLayer->addChild(maxLabel);

    // --- presets ---
    int presets[4] = {60, 120, 240, 500};
    for (int i = 0; i < 4; i++) {
        auto* spr = ButtonSprite::create(std::to_string(presets[i]).c_str(), "goldFont.fnt", "GJ_button_04.png", 0.6f);
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(LagFixerPopup::onPreset));
        btn->setTag(presets[i]);
        btn->setPosition({cx - 105 + i * 70.f, 45});
        menu->addChild(btn);
    }

    refreshLabel();
    return true;
}

void LagFixerPopup::refreshLabel() {
    int fps = static_cast<int>(Mod::get()->getSettingValue<int64_t>("fps"));
    bool on = Mod::get()->getSettingValue<bool>("enabled");
    m_fpsLabel->setString(fmt::format("FPS: {}{}", fps, on ? "" : " (off)").c_str());
}

void LagFixerPopup::onToggle(CCObject*) {
    // the toggler flips after the callback, so the new state is the opposite
    bool nowOn = !m_toggle->isToggled();
    Mod::get()->setSettingValue<bool>("enabled", nowOn);
    lagfixer::apply();
    refreshLabel();
}

void LagFixerPopup::onSlider(CCObject* sender) {
    auto* thumb = static_cast<SliderThumb*>(sender);
    float v = std::clamp(thumb->getValue(), 0.f, 1.f);
    int fps = kMinFps + static_cast<int>(std::lround(v * (kMaxFps - kMinFps)));
    Mod::get()->setSettingValue<int64_t>("fps", fps);
    if (Mod::get()->getSettingValue<bool>("enabled")) lagfixer::apply();
    refreshLabel();
}

void LagFixerPopup::onPreset(CCObject* sender) {
    int fps = static_cast<CCNode*>(sender)->getTag();
    Mod::get()->setSettingValue<int64_t>("fps", fps);
    m_slider->setValue(static_cast<float>(fps - kMinFps) / static_cast<float>(kMaxFps - kMinFps));
    if (Mod::get()->getSettingValue<bool>("enabled")) lagfixer::apply();
    refreshLabel();
}
