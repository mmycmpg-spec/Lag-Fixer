#include "LagFixer.hpp"
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/OptionsLayer.hpp>

// Apply the saved settings as soon as the game menu appears
class $modify(LagFixerMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        lagfixer::apply();
        return true;
    }
};

// "Lag Fixer" button inside the GD Settings screen
class $modify(LagFixerOptionsLayer, OptionsLayer) {
    void customSetup() {
        OptionsLayer::customSetup();

        auto winSize = CCDirector::sharedDirector()->getWinSize();

        auto* menu = CCMenu::create();
        menu->setPosition({0, 0});

        auto* spr = ButtonSprite::create("Lag Fixer", "goldFont.fnt", "GJ_button_01.png", 0.7f);
        auto* btn = CCMenuItemSpriteExtra::create(
            spr, this, menu_selector(LagFixerOptionsLayer::onLagFixer));
        btn->setPosition({winSize.width - 75.f, winSize.height - 40.f});
        menu->addChild(btn);

        m_mainLayer->addChild(menu, 10);
    }

    void onLagFixer(CCObject*) {
        LagFixerPopup::create()->show();
    }
};
