#include <Geode/Geode.hpp>
#include "LagFixer.hpp"

using namespace geode::prelude;

$on_mod(Loaded) {
    log::info("LAG FIXER loaded");
}
