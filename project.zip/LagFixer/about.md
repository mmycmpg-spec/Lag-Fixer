# LAG FIXER

One button to make Geometry Dash run smoother.

**How to use**
1. Open Geometry Dash **Settings** (the gear).
2. Tap **Lag Fixer**.
3. Tick **Fix Lag** and pick an FPS (60 to 500).

**What it does while ON**
- Sets the game's FPS target (60 - 500).
- Turns on Performance mode and turns off V-Sync.
- Turns on Low Detail mode in levels (less decoration and effects = less work for your device).

**Tip:** if you still lag, pick **60** - a steady 60 FPS feels smoother than a high number your device cannot reach. Turn Fix Lag off to put everything back.
