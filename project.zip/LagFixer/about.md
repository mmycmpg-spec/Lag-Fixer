# LAG FIXER

One button to make Geometry Dash and Geode run smoother.

**How to use**
1. Open Geometry Dash **Settings** (the gear).
2. Tap **Lag Fixer**.
3. Tick **Fix Lag** and drag the slider from **60 to 500 FPS**.

**What it does**
- Sets the game's FPS target (60 - 500).
- Turns on Performance mode and turns off V-Sync while enabled, to cut lag.
- Turn it off and everything goes back to how it was.

A higher FPS target is smoother only if your device can keep up. If it gets hot or stutters, lower the slider.
